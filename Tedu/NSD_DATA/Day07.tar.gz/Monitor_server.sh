#!/bin/bash
Ip_address=`ifconfig eth0 | awk '/inet /{print $2}'`
echo "本机IP地址为：$Ip_address"
#监控CPU
CPU_use=`uptime | awk '{print $NF}'`
echo "CPU使用情况：$CPU_use"
#监控流量
RX_packets=`ifconfig eth0 | awk '/RX p/{print $5}'`
echo "接受网卡流量为：$RX_packets"
TX_packets=`ifconfig eth0 | awk '/TX p/{print $5}'`
echo "发送网卡流量为：$TX_packets"
#监控内存
Mem_total=`free | awk '/Mem/{print $2}'`
echo "系统内存大小：$Mem_total"
Mem_free=`free | awk '/Mem/{print $4}'`
echo "系统剩余内存空间：$Mem_free"
#监控磁盘
Disk_size=`df / | awk '/\//{print $2}'`
echo "系统磁盘大小：$Disk_size"
Disk_free=`df / | awk '/\//{print $4}'`
echo "系统磁盘剩余空间：$Disk_free"
#监控本机账户数量
User_total=`cat /etc/passwd | wc -l`
echo "本机用户数量：$User_total"
#监控当前登陆用户数量
User_login=`who | wc -l`
echo "当前登陆用户数量：$User_login"
#监控当前开启进程数
Top_login=`ps aux | wc -l`
echo "本机当前开启的进程数量：$Top_login"
#监控已安装软件包数量
Software_packages=`rpm -qa | wc -l`
echo "本机已安装软件包数量：$Software_packages"
