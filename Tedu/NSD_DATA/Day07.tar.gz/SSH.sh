#!/bin/bash
#检测ssh登录日志，如果远程登陆账号名错误3次，则屏蔽远程主机的IP 
Blacklist_user=`awk '/Invalid user/{print $11}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print ip[i],i}}' | awk '$1>3{print $2}'`
#检测ssh登录日志，如果远程登陆密码错误3次，则屏蔽远程主机的IP 
Blacklist_pass=`awk '/Failed password/{print $11}' /var/log/secure | awk '{ip[$1]++}END{for(i in ip){print ip[i],i}}' | awk '$1>3{print $2}'`

