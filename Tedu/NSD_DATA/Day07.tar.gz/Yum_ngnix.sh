#!/bin/bash
Yum_size=`yum repolist | awk '/repolist/{print $2}' | sed 's/,//'`
if [ $Yum_size -le 0 ];then
  echo "没有可用的Yum源！"
  exit
fi
yum -y install gcc openssl-devel pcre-devel
tar -xf /root/lnmp_soft/nginx-1.12.2.tar.g
cd /root/nginx-1.12.2
./configure
make
make install
