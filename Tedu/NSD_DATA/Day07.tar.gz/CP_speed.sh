#!/bin/bash
CP_speed(){
while :
do
	echo -n "#"
	sleep 0.1
done
}
echo -n "["
CP_speed &
cp -r $1 $2
kill $!
echo "]拷贝完成！"
