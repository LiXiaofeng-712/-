#!/bin/bash
if [ "$1" == "start" ];then
	/usr/local/nginx/sbin/nginx
elif [ "$1" == "stop" ];then
	/usr/local/nginx/sbin/nginx -s stop
elif [ "$1" == "restart" ];then
	/usr/local/nginx/sbin/nginx -s stop
	/usr/local/nginx/sbin/nginx
elif [ "$1" == "status" ];then
	ss -ntulp | grep nginx &> /dev/null
	if [ $? -eq 0 ];then
		echo "服务已启动！"
	else
		echo "服务未启动！"
	fi
else
	echo "Error！" 
fi

